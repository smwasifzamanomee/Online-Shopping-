
<?php include('admin/config/constants.php'); ?>


<?php
// $ip = $_SERVER['REMOTE_ADDR'];
$sql = "SELECT * FROM cart";
$res = mysqli_query($conn, $sql);
$count = @mysqli_num_rows($res);
if($count <= 0){
	$count = 0;
}


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>SR Mart | Online Shopping</title>
        <link rel="stylesheet" href="style.css">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="header">
        <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="index.php"><img src="Images/logo.jpg" width="125px"> </a>
            </div>
            <nav>
                <ul id="MenuItems">
                    <li> <a href="index.php">Home</a></li>
                    <li> <a href="category.php">Categories</a></li>
                    <li> <a href="products.php">Products</a></li>
                    <li> <a href="contact.php">Contact</a></li>
                    <li> <a href="cart.php">Cart <sup>[<?php echo $count; ?>]</sup> </a></li>
                </ul>
            </nav>
            
        </div>
        </div>
        </div>
        
        <!-- featured categories -->
        
        <div clas="small-container">
            <h2 class="title">Categories</h2><br><br>
            <div class="row">
         <?php
        $sql= "SELECT * FROM tbl_category";
        $res = mysqli_query($conn , $sql);

        if($res == True)
        {
            $count =mysqli_num_rows($res);

            if($count>0)
            {
                while($rows= mysqli_fetch_assoc($res))
                {
                    $id= $rows['id'];
                    $image= $rows['image_name'];
                    $title =$rows['title'];
                    $active=$rows['active'];
                    if($active=="Yes"){


                        ?>
                    <div class="col-3">
                    <img src="admin/image/category/<?php echo $image ?>">
                    <h4><?php echo $title ?> </h4> 
                    </div>
                
     <?php
                }
            }
         }
            else{
                echo "No Category Found";
                 
                }   

        }  
    ?>


                </div>
            </div>
        </div>
        
       
        
        <!--- footer --->
        
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-col-1">
                        <h3>Download Our App</h3>
                        <p>Download App for Andriod and iso mobile phone</p>
                        <div class="app-logo">
                            <img src="Images/playstore.png">
                            <img src="Images/appstore.png" height="56.5px">
                        </div>
                    </div>
                    <div class="footer-col-2">
                        <img src="Images/logo.jpg">
                        <p>our Purpose is to sustainably make the pleasure and benefits of sports accessible to the way</p>
                    </div>
                    <div class="footer-col-4">
                        <h3>Follow Us</h3>
                        <ul>
                            <li>Facebook</li>
                            <li>Twitter</li>
                            <li>Instagram</li>
                            <li>Youtube</li>
                        </ul>
                    </div>
                    
                </div>
                <hr>
                <p align="center">2021 All rights reserved, Online Shopping. Developed by Wasif Zaman Omee</p>
            </div>
        </div>
    </body>   
</html>