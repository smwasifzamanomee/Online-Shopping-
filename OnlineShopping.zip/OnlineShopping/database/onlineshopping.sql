-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 24, 2021 at 12:40 PM
-- Server version: 5.7.24
-- PHP Version: 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlineshopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(10) NOT NULL,
  `product` varchar(255) NOT NULL,
  `qty` int(10) NOT NULL,
  `price` varchar(10) NOT NULL,
  `subtotal` varchar(10) NOT NULL,
  `identity` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `product`, `qty`, `price`, `subtotal`, `identity`) VALUES
(1, '17', 1, '250.00', '250', ''),
(2, '7', 1, '1000.00', '1000', '');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `order_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `price` varchar(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `subtotal` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `full_name`, `username`, `password`) VALUES
(11, 'Wasif Zaman Omee', 'wasifzamanomee', '1234'),
(12, 'sharmin sultana', 'sharmin', '1234'),
(16, 'Admistration', 'admin', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(12, '  lipstick', 'product_category_931.jpg', 'Yes', 'Yes'),
(19, ' Bag', 'product_category_340.jpg', 'Yes', 'Yes'),
(20, 'Shoe', 'product_category_637.jpg', 'Yes', 'Yes'),
(21, 'watch', 'product_category_175.jpg', 'Yes', 'Yes'),
(28, 'Nuduls', 'product_category_92.jpg', 'Yes', 'Yes'),
(29, 'Band', 'product_category_187.jpg', 'Yes', 'Yes'),
(30, 'Hair Color', 'product_category_544.jpg', 'Yes', 'Yes'),
(31, 'Makeup Box ', 'product_category_414.jpg', 'Yes', 'Yes'),
(32, 'Loson ', 'product_category_734.jpg', 'Yes', 'Yes'),
(33, 'Tawal', 'product_category_161.jpg', 'Yes', 'Yes'),
(34, 'Eye Layer', 'product_category_286.jpg', 'Yes', 'Yes'),
(35, 'State Machine ', 'product_category_431.jpg', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `products` varchar(150) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(10,0) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contacts` varchar(20) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_products`
--

CREATE TABLE `tbl_products` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `rating` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `featured` varchar(10) NOT NULL,
  `stock` varchar(5) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_products`
--

INSERT INTO `tbl_products` (`id`, `title`, `rating`, `price`, `image_name`, `category_id`, `featured`, `stock`, `active`) VALUES
(5, ' Apex 303', ' good', '400.00', 'product_name_477.jpg', 20, 'Yes', 'Yes', 'Yes'),
(6, ' Hanrahan lipstick ', ' good', '150.00', 'product_name_572.jpg', 12, 'Yes', 'No', 'Yes'),
(7, 'Travel luggage ', ' good', '1000.00', 'product_name_168.jpg', 12, 'Yes', 'Yes', 'Yes'),
(11, 'Me Lepta lipstick', '', '150.00', 'product_name_119.jpg', 12, 'Yes', 'Yes', 'Yes'),
(12, ' Small Parse', '', '0.00', 'product_name_632.jpg', 19, 'Yes', 'Yes', 'Yes'),
(14, ' Teayason Color', '', '80.00', 'product_name_833.jpg', 30, 'Yes', 'No', 'Yes'),
(15, 'High Hill', '', '400.00', 'product_name_237.jpg', 20, 'Yes', 'Yes', 'Yes'),
(16, 'Makeup Box ', '', '500.00', 'product_name_779.jpg', 12, 'Yes', 'Yes', 'Yes'),
(17, 'Pop Chips ', '', '250.00', 'product_name_772.jpg', 12, 'Yes', 'Yes', 'Yes'),
(18, 'Standard Loson', '', '800.00', 'product_name_475.jpg', 29, 'Yes', 'Yes', 'Yes'),
(19, ' State Machine ', '', '230.00', 'product_name_451.jpg', 35, 'Yes', 'Yes', 'Yes'),
(21, 'Remover', '', '70.00', 'product_name_900.jpg', 12, 'Yes', 'Yes', 'Yes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_products`
--
ALTER TABLE `tbl_products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_products`
--
ALTER TABLE `tbl_products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
