
<?php include('admin/config/constants.php'); ?>


<?php
// $ip = $_SERVER['REMOTE_ADDR'];
$sql = "SELECT * FROM cart";
$res = mysqli_query($conn, $sql);
$count = @mysqli_num_rows($res);
if($count <= 0){
	$count = 0;
}


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>SR Mart | Online Shopping</title>
        <link rel="stylesheet" href="style.css">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="header">
        <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="index.php"><img src="Images/logo.jpg" width="125px"> </a>
            </div>
            <nav>
                <ul id="MenuItems">
                    <li> <a href="index.php">Home</a></li>
                    <li> <a href="category.php">Categories</a></li>
                    <li> <a href="products.php">Products</a></li>
                    <li> <a href="contact.php">Contact</a></li>
                    <li> <a href="cart.php">Cart <sup>[<?php echo $count; ?>]</sup> </a></li>
                </ul>
            </nav>
            
        </div>
        </div>
        </div>
        
        <!-- Contact  -->
        <br>
        <div class="col10 text-center">
        <h1> Contact Us </h1><br><br><br>
        <h2><u> Address </u> </h3><br>
        <i class="fa fa-map-marker" aria-hidden="true"></i><p>Barandi Molla Para Amtala,Jessore</p><br>
        <h2><u>Email </u></h3><br>
        <i class="fa fa-envelope-o" aria-hidden="true"></i><p>wasifbdjsr@gmail.com<p><br>
        <h2><u>Contact Number</u></h3><br>
        <i class="fa fa-phone-square" aria-hidden="true"></i><p>01910312566</p><br>
        <h2><u>Facebook Page</u></p><br>
        <i class="fa fa-facebook-square" aria-hidden="true"></i><p>Sr Mart </p><br>
</div>
        
        <!--- footer --->
        
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-col-1">
                        <h3>Download Our App</h3>
                        <p>Download App for Andriod and iso mobile phone</p>
                        <div class="app-logo">
                            <img src="Images/playstore.png">
                            <img src="Images/appstore.png" height="56.5px">
                        </div>
                    </div>
                    <div class="footer-col-2">
                        <img src="Images/logo.jpg">
                        <p>our Purpose is to sustainably make the pleasure and benefits of sports accessible to the way</p>
                    </div>
                    <div class="footer-col-4">
                        <h3>Follow Us</h3>
                        <ul>
                            <li>Facebook</li>
                            <li>Twitter</li>
                            <li>Instagram</li>
                            <li>Youtube</li>
                        </ul>
                    </div>
                    
                </div>
                <hr>
                <p align="center">2021 All rights reserved, Online Shopping. Developed by Wasif Zaman Omee</p>
            </div>
        </div>
    </body>   
</html>