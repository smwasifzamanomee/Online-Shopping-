<?php include('partials/menu.php') ?>


<div class="main-content">
        <div class="wrapper">
            
             <h1> Add Products </h1> <br>

             <form action="" method="POST" enctype="multipart/form-data">

        <table class="tbl-30">
            <tr>
                <td> TITLE </td>
                <td> <input type="text" name="title" placeholder=" product title"> </td>
            </tr>
            <tr>
                <td> Stock </td>
                <td> 
                    <input type="radio" value="Yes" name="stock" placeholder=" Yes" checked > Yes 
                    <input type="radio" value="No" name="stock" placeholder=" No" > No 
                </td>
            </tr>
            <tr>
                <td> PRICE </td>
                <td> <input type="text" name="price" placeholder=" product price"> </td>
            </tr>
            <tr>
                <td> SELECT IMAGE </td>
                <td> <input type="file" name="image"> </td>
            </tr>
            <tr>
                <td> CATEGORY </td>
                <td> 
                    <select name='category'>
                        <?php  
                        //sql quarry for selective category from category table 
                        $sql="SELECT * FROM tbl_category WHERE active='Yes'";

                        $res=mysqli_query($conn, $sql);

                        $count = mysqli_num_rows($res);

                        if($count>0)
                        {
                            //we have category
                            while($row=mysqli_fetch_assoc($res))
                            {
                                //detail category
                                $id= $row['id'];
                                $title= $row['title'];
                                ?>
                                <option value="<?php echo $id; ?>"><?php echo $title; ?></option>
                                <?php
                            }
                        }
                        else{
                            //have not category
                            ?>
                            <option value="0">No Category Found</option>
                            <?php 
                            
                        }
                        ?>
                        

                    </select>
                </td>
            </tr>
            <tr>
                <td> FEATURED </td>
                <td> 
                    <input type="radio" value="Yes" name="featured" placeholder=" Yes"> Yes
                    <input type="radio" value="No" name="featured" placeholder=" No"> No
                </td>
            </tr>
            <tr>
                <td> ACTIVE  </td>
                <td> 
                    <input type="radio" value="Yes" name="active" placeholder=" Yes"> Yes
                    <input type="radio" value="No" name="active" placeholder=" No"> No
                </td>
            </tr>
            <tr>
                
                <td colspan="2"> <input type="submit" name="submit" value="Add Products" class="clr-vpp1"> </td>
            </tr>

        </table>
        </form>

        <?php 
       
       if(isset($_POST['submit']))
       {
            $title = $_POST['title'];
            //$rating= $_POST['rating'];
            $price= $_POST['price'];
            $category= $_POST['category'];
            $stock =$_POST['stock'];

           if(isset($_POST['featured']))
           {
               $featured = $_POST['featured'];
           }
           else{
               $featured="No";
           }

           if(isset($_POST['active']))
           {
               $active= $_POST['active'];
           }
           else{
               $active = "No";
           } 

           // executed image 
           if(isset($_FILES['image']['name']))
           {
                $image_name = $_FILES['image']['name'];
                // image jpg formate
                $ext = end(explode('.', $image_name));
                //rename image
                $image_name= "product_name_" .rand(000 , 999).'.' .$ext;
                $source_path = $_FILES['image']['tmp_name'];
                $destination_path = "image/products/".$image_name;
                $upload =  move_uploaded_file($source_path, $destination_path);

               /* if($upload==false)
                {
                    $_SESSION['upload']= "<div class='error' > Failed to upload image.</div>";
                    header("Location: admin/add-products.php");
                    die();
                } */
           }
           else{
                    $image_name="";
           }

           //sql 
           
           $sql= "INSERT INTO tbl_products (title,price,category_id,image_name, featured, stock, active) VALUES ('$title','$price',$category,'$image_name','$featured','$stock','$active')";

           // executed database

           $res= mysqli_query($conn , $sql);

           // check executed or not 
           if($res==true)
            {
               // echo "data show";
               //$_SESSION['add']="Admin Added Successfully";


              header("Location: manage-products.php?res=Ok");
            }
            else{
                   // echo "data show failed";
                   header("Location: manage-products.php?res=No");
            }
       }
           ?>

</div>
</div>


             
<?php include('partials/footer.php') ?>