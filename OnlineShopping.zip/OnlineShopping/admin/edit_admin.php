
<?php include('partials/menu.php') ?>
    <!-- Main content section starts -->
    <div class="main-content">
        <div class="wrapper">
             <!--<h1 align="center"> SR MART ONLINE SHOPPING </h1><br /> -->
			 <?php
			 if(isset($_GET["edit"])){
				 $id = $_GET["edit"];
				 $sql = "SELECT * FROM tbl_admin WHERE id=".$id;
				 $query = mysqli_query($conn, $sql);
				 $res = mysqli_fetch_assoc($query);				 
				 
			 }
			 ?>
             <h1> Edit Admin</h1>
             <br>



             <form action="" method="POST">

                <table class="tbl-30">
                    <tr>
                        <td> FULL NAME </td>
                        <td> <input type="text" name="full_name" value="<?php echo $res["full_name"]; ?>" </td>
                    </tr>
                    <tr>
                        <td> USER NAME </td>
                        <td> <input type="text" name="username" value="<?php echo $res["username"]; ?>"> </td>
                    </tr>
                    <tr>
                        <td> PASSWORD  </td>
                        <td> <input type="text" name="password" value="<?php echo $res["password"]; ?>"> </td>
                    </tr>
                    <tr>
                        
                        <td colspan="2"> <input type="submit" name="submit" value="Update Admin" class="clr-vpp1"> </td>
                    </tr>

                </table>


            </form>
             
        </div>

    </div>

    <?php 
       if(isset($_POST['submit']))
       {
            $full_name=$_POST['full_name'];
            $username=$_POST['username'];
            $password=$_POST['password'];

            //SQL
            $edit_sql= "UPDATE tbl_admin SET full_name='".$full_name."',username='".$username."',password='".$password."' WHERE id=".$id;


            //connection Database
            

           
            $edit_res= mysqli_query($conn, $edit_sql) or die(mysqli_error($conn));

            if($edit_res==true)
            {
               //echo "Data Updated";
               header("Location: manage-admin.php?update=Ok");
            }
            else{
                //echo "Data Update Failed";
                header("Location: manage-admin.php?update=No");
            }
       }
    ?>
         <!-- Main content section end -->
<?php include('partials/footer.php') ?>
