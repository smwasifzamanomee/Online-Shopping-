
<?php include('partials/menu.php') ?>
    <!-- Main content section starts -->
    <div class="main-content">
        <div class="wrapper">
             <!--<h1 align="center"> SR MART ONLINE SHOPPING </h1><br /> -->
			 <?php
			 if(isset($_GET["edit"])){
				 $id = $_GET["edit"];
				 $sql = "SELECT * FROM tbl_category WHERE id=".$id;
				 $query = mysqli_query($conn, $sql);
				 $res = mysqli_fetch_assoc($query);				 
				 
			 }
			 ?>
             <h1> Edit Category</h1>
             <br>



             <form action="" method="POST" enctype="multipart/form-data">

                <table class="tbl-30">
                <tr>
                <td> TITLE </td>
                <td> <input type="text" name="title" value=" <?php echo $res['title'] ?>"> </td>
            </tr>
            <tr>
                <td> CURRENT IMAGE </td>
                <td> <img src ="image/category/<?php echo  $res ['image_name'] ?>" height="100px" > </td>
            </tr>
            <tr>
                <td> SELECT IMAGE </td>
                
                <td> <input type="file" name="image" > </td>
            </tr>
            <tr>
                <td> FEATURED </td>
                <td> 
                    <input type="radio" value="Yes" name="featured" <?php if($res['featured']=="Yes") echo 'checked' ?>> Yes
                    <input type="radio" value="No" name="featured" <?php if($res['featured']=="No") echo 'checked' ?>> No
                </td>
            </tr>
            <tr>
                <td> ACTIVE  </td>
                <td> 
                    <input type="radio" value="Yes" name="active" <?php if($res['active']=="Yes") echo 'checked' ?>> Yes
                    <input type="radio" value="No" name="active" <?php if($res['active']=="No") echo 'checked' ?>> No
                </td>
            </tr>
            <tr>
                
                <td colspan="2"> <input type="submit" name="submit" value="Update Category" class="clr-vpp1"> </td>
            </tr>

                </table>


            </form>
             
        </div>

    </div>

    <?php 
       if(isset($_POST['submit']))
       {
          //image
          if(isset($_FILES['image']['name']))
           {
                $image_name = $_FILES['image']['name'];
                // image jpg formate
                $ext = end(explode('.', $image_name));
                //rename image
                $image_name= "product_category_" .rand(000 , 999).'.' .$ext;
                $source_path = $_FILES['image']['tmp_name'];
                $destination_path = "image/category/".$image_name;
                $upload =  move_uploaded_file($source_path, $destination_path);
           }
           else{
                    $image_name=$res['image_name'];
           }
           
            $title=$_POST['title'];
            $featured=$_POST['featured'];
            $active=$_POST['active'];

            //SQL
            $edit_sql= "UPDATE tbl_category SET image_name='".$image_name."',title='".$title."',featured='".$featured."' ,active='".$active."' WHERE id=".$id;
           // echo $edit_sql;
           

            //connection Database
            

           
            $edit_res= mysqli_query($conn, $edit_sql) or die(mysqli_error($conn));

           if($edit_res==true)
            {
               //echo "Data Updated";
               header("Location: manage-category.php?update=Ok");
            }
            else{
                //echo "Data Update Failed";
                header("Location: manage-category.php?update=No");
            }
       }
    ?>
         <!-- Main content section end -->
<?php include('partials/footer.php') ?>
