
<?php
include('partials/menu.php');
//category counter
$cat_sql = "SELECT COUNT(id) FROM tbl_category";
$cat_res = mysqli_query($conn, $cat_sql);
$cat_row = mysqli_fetch_array($cat_res);
$cat_count = $cat_row[0];

//product counter
$product_sql = "SELECT COUNT(id) FROM tbl_products";
$product_res = mysqli_query($conn, $product_sql);
$product_row = mysqli_fetch_array($product_res);
$product_count = $product_row[0];

//order counter
$order_sql = "SELECT COUNT(id), SUM(total) FROM tbl_order";
$order_res = mysqli_query($conn, $order_sql);
$order_row = mysqli_fetch_array($order_res);
$order_count = $order_row[0];

//total sell counter
$sell_sql = "SELECT SUM(total) FROM tbl_order WHERE status='Complete'";
$sell_res = mysqli_query($conn, $sell_sql);
$sell_row = mysqli_fetch_array($sell_res);
$sell_count = $sell_row[0];
if(empty($sell_count)){
	$sell_count = 0;
}




?>
    <!-- Main content section starts -->
    <div class="main-content">
        <div class="wrapper">
            <h1 align="center"> SR MART ONLINE SHOPPING </h1><br /> 
            
             <h1> DASHBOARD </h1>
             <br> <br> <br> <br>

              
             
              <div class="col-4 text-center">
                 <h1><?php echo $cat_count; ?></h1>
                 <br />
                 Total Categories
            </div>

            <div class="col-4 text-center">
                 <h1><?php echo $product_count; ?></h1>
                 <br />
                 Total Products
            </div>

            <div class="col-4 text-center">
                 <h1><?php echo $order_count; ?></h1>
                 <br />
                 Total Orders
            </div>

            <div class="col-4 text-center">
                 <h1><?php echo $sell_count; ?></h1>
                 <br />
                 Total Sell (BDT)
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
     <!-- Manu Section End -->

 <?php include('partials/footer.php') ?>
