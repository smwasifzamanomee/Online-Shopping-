
<?php include('partials/menu.php') ?>
    <!-- Main content section starts -->
    <div class="main-content">
        <div class="wrapper">
             <!--<h1 align="center"> SR MART ONLINE SHOPPING </h1><br /> -->
			 <?php
			 if(isset($_GET["edit"])){
				 $id = $_GET["edit"];
				 $sql = "SELECT * FROM tbl_products WHERE id=".$id;
				 $query = mysqli_query($conn, $sql);
				 $res = mysqli_fetch_assoc($query);				 
				 
			 }
			 ?>
             <h1> Edit Products</h1>
             <br>



             <form action="" method="POST" enctype="multipart/form-data">

                <table class="tbl-30">
                <tr>
                <td> TITLE </td>
                <td> <input type="text" name="title" value=" <?php echo $res['title'] ?>"> </td>
            </tr>
            <tr>
                <td> CURRENT IMAGE </td>
                <td> <img src ="image/products/<?php echo  $res ['image_name'] ?>" height="100px" > </td>
            </tr>
            <tr>
                <td> SELECT IMAGE </td>
                
                <td> <input type="file" name="image" > </td>
            </tr>
            <tr>
                <td> PRICE </td>
                
                <td> <input type="number" name="price" value=" <?php echo $res['price'] ?>" > </td>
            </tr>
            <tr>
                <td> FEATURED </td>
                <td> 
                    <input type="radio" value="Yes" name="featured" <?php if($res['featured']=="Yes") echo 'checked' ?>> Yes
                    <input type="radio" value="No" name="featured" <?php if($res['featured']=="No") echo 'checked' ?>> No
                </td>
            </tr>
            <tr>
                <td> STOCK </td>
                <td> 
                    <input type="radio" value="Yes" name="stock" <?php if($res['stock']=="Yes") echo 'checked' ?>> Yes
                    <input type="radio" value="No" name="stock" <?php if($res['stock']=="No") echo 'checked' ?>> No
                </td>
            </tr>
            <tr>
                <td> ACTIVE  </td>
                <td> 
                    <input type="radio" value="Yes" name="active" <?php if($res['active']=="Yes") echo 'checked' ?>> Yes
                    <input type="radio" value="No" name="active" <?php if($res['active']=="No") echo 'checked' ?>> No
                </td>
            </tr>
            <tr>
                
                <td colspan="2"> <input type="submit" name="submit" value="Update Products" class="clr-vpp1"> </td>
            </tr>

                </table>


            </form>
             
        </div>

    </div>

    <?php 
       if(isset($_POST['submit']))
       {
          //image
          if(isset($_FILES['image']['name']))
           {
                $image_name = $_FILES['image']['name'];
                // image jpg formate
                $ext = end(explode('.', $image_name));
                //rename image
                $image_name= "product_name_" .rand(000 , 999).'.' .$ext;
                $source_path = $_FILES['image']['tmp_name'];
                $destination_path = "image/products/".$image_name;
                $upload =  move_uploaded_file($source_path, $destination_path);
           }
           else{
                    $image_name=$res['image_name'];
           }
           
            $title=$_POST['title'];
            $price=$_POST['price'];
            $featured=$_POST['featured'];
            $stock=$_POST['stock'];
            $active=$_POST['active'];

            //SQL
            $edit_sql= "UPDATE tbl_products SET image_name='".$image_name."',title='".$title."',price='".$price."',featured='".$featured."' ,stock='".$stock."',active='".$active."' WHERE id=".$id;
           // echo $edit_sql;
           

            //connection Database
            

           
            $edit_res= mysqli_query($conn, $edit_sql) or die(mysqli_error($conn));

           if($edit_res==true)
            {
               //echo "Data Updated";
               header("Location: manage-products.php?update=Ok");
            }
            else{
                //echo "Data Update Failed";
                header("Location: manage-products.php?update=No");
            }
       }
    ?>
         <!-- Main content section end -->
<?php include('partials/footer.php') ?>
