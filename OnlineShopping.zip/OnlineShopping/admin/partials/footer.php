<!-- footer Section starts -->
<div class="footer">
         <div class="wrapper">
            <p class="text-center">2021 All rights reserved, Online Shopping. Developed by Wasif Zaman Omee</p>
        </div>
    </div>
      <!-- footer Section End -->
    </body>


</html>