
<?php include('config/constants.php'); ?>
<html>
    <head>
       <title>Products order webside - Home Page</title>
       
       <link rel="stylesheet" href="../css/admin.css">
      <!-- <link rel="stylesheet" href="../bootstrap/css/bootstrap.css">
       <script src="../bootstrap/js/bootstrap.js"> </script>
-->

    </head>

    <body>
    <!-- Manu Section Strats -->
    <div class="menu text-center">
        <div style="padding:20px">
           <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="manage-admin.php">Admin</a></li>
                <li><a href="manage-category.php">Category</a></li>
                <li><a href="manage-products.php">Products</a></li>
                <li><a href="manage-order.php">Order</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div> 
    <!-- Manu Section End -->