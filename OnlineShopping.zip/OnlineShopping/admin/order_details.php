<?php
include('partials/menu.php');


if(!isset($_GET["id"])){
	header('Location: manage-order.php');
}else{
	$id = $_GET["id"];
	$sql = "SELECT * FROM tbl_order WHERE id=".$id;
	$res = mysqli_query($conn, $sql);
	$count = mysqli_num_rows($res);
}
?>

 <!-- Main content section starts -->
 <div class="main-content">
        <div class="wrapper">
             <!--<h1 align="center"> SR MART ONLINE SHOPPING </h1><br /> -->
            
             <h1 align="center"> Order Details </h1><hr><br>
			 <?php
			 if($count <= 0){ //exception handle for wrong order number view
				 echo "<script>alert('Wrong Order Number');document.location='manage-order.php'</script>";
			 }else{
				 $row = mysqli_fetch_assoc($res);
				 $total = $row['total'];
				 $order_date = $row['order_date'];
				 $status = $row['status'];
				 
				 $cus_name = $row['customer_name'];
				 $cus_mob = $row['customer_contacts'];
				 $cus_email = $row['customer_email'];
				 $cus_address = $row['customer_address'];
				 
				 
				 
			 }
			 ?>
			 <h2>Customer Details</h2>
			 <table width="auto">
				<tr>
					<td>Name</td><td><?php echo $cus_name;?></td>
				</tr>
				<tr>
					<td>Contact</td><td><?php echo $cus_mob;?></td>
				</tr>
				<tr>
					<td>Email</td><td><?php echo $cus_email;?></td>
				</tr>
				<tr>
					<td>Address</td><td><?php echo $cus_address;?></td>
				</tr>
			</table>
			<hr><br>
			
			 <h2>Order Information</h2>
			 <form method="POST">
			<table width="auto">
				<tr>
					<td>Order Id </td><td><?php echo $id;?></td>
				</tr>
				<tr>
					<td>Order Date</td><td><?php echo $order_date;?></td>
				</tr>
				<tr>
					<td>Total Price</td><td><?php echo $total;?></td>
				</tr>
				<tr>
					<td>Status</td>
					<td>
						<select name="status">
							<?php
							if($status == "Pending"){
								echo '<option value="Pending">Pending</option>
								<option valie="Complete">Complete</option>';
							}else{
								echo '<option valie="Complete">Complete</option>
								<option value="Pending">Pending</option>';
							}
							?>
						</select>
					</td>
				</tr>
			</table>
			<hr><br>
			
			<h2>Product Details</h2>

			 <table width="auto">
				<tr>
					<td>Product Image</td>
					<td>Product Name</td>
					<td>Quantity</td>
					<td>Price</td>
					<td>Subtotal</td>
				</tr>
				<?php
				$detail_sql = "SELECT tbl_products.title,tbl_products.image_name,order_details.* FROM order_details,tbl_products WHERE order_details.product_id = tbl_products.id AND order_details.order_id=".$id;
				$detail_res = mysqli_query($conn, $detail_sql);
				while($detail_row = mysqli_fetch_assoc($detail_res)){
				 $product_name = $detail_row['title'];
				 $product_img = $detail_row['image_name'];
				 $qty = $detail_row['qty'];
				 $price = $detail_row['price'];
				 $subtotal = $detail_row['subtotal'];
				 ?>
			
				<tr>
					<td><img src="image/products/<?php echo $product_img; ?>" height="100px"></td>
					<td><?php echo $product_name;?></td>
					<td><?php echo $qty;?></td>
					<td><?php echo $price;?></td>
					<td><?php echo $subtotal;?></td>
				</tr>
				<?php
				}
				?>
			</table>
			<hr><br>
			<input type="submit" class="btn" name="update" value="Update Order">
			</form>
			<?php
			if(isset($_POST["update"])){
				$status = $_POST["status"];
				$up_sql = "UPDATE tbl_order SET status='".$status."' WHERE id=".$id;
				// echo $up_sql;
				$up_res = mysqli_query($conn, $up_sql);
				if($up_res){
					echo '<script>alert("Order information has been changed");document.location="manage-order.php"</script>';
				}else{
					echo '<script>alert("Something went wrong");</script>';
				}
			}
			?>
			</div>	
<?php include('partials/footer.php') ?>
			