<?php include('partials/menu.php') ?>
    <!-- Main content section starts -->
    <div class="main-content">
        <div class="wrapper">
             <!--<h1 align="center"> SR MART ONLINE SHOPPING </h1><br /> -->
            
             <h1> Manage Products</h1>
             <br>
             
             <?php
			 if(isset($_GET["res"]) && $_GET["res"] == "Ok"){
				 echo "New Products Added";
			 }
             if(isset($_GET["res"]) && $_GET["res"] == "No"){
                echo "Invalid";
             }
			 ?>

            <?php
			 if(isset($_GET["update"]) && $_GET["update"] == "Ok"){
				 echo "Successfully Update";
			 }
             if(isset($_GET["update"]) && $_GET["update"] == "No"){
                echo "Invalid";
             }
			 ?>

             
           <?php
            if(isset($_GET["delete"])){
				$del = $_GET["delete"];
				$delete_sql = "DELETE FROM tbl_products WHERE id=".$del;
				$del_res = mysqli_query($conn, $delete_sql);
				if($del_res == True){
					echo '<script>alert("Data Delete Success")</script>';
				}else{
					echo '<script>alert("Data Delete Failed")</script>';
				}
				
			 }
             ?>

             <!-- Botton to add admin-->
            <!-- <a href="#" class=" btn btn-success" > Add Admin </a> <br><br> -->
             <br><br>
             <a href="add-products.php" class="clr-vpp"> Add Products </a> <br> <br>

             <table class="tbl-full">
                 
                <tr> 
                    <th> S.N.</th>
                    <th> Image  </th>
                    <th> Products Name </th>
                    <th> Price </th>
                   <!-- <th> Rating </th> -->
                    <th> Featured  </th>
                    <th> Stock </th>
                    <th> Active </th>
                    <th> Actions </th>
                </tr>
            
               <?php 
                 $sql= "SELECT * FROM tbl_products";
                 $res = mysqli_query($conn , $sql);

                 if($res == True)
                 {
                     $count =mysqli_num_rows($res);

                     if($count>0)
                     {
                          $sl=0;
                            while($rows= mysqli_fetch_assoc($res))
                            {
                                $id= $rows['id'];
                                $image= $rows['image_name'];
                                $title =$rows['title'];
                                $price=$rows['price'];
                                //$rating= $rows['rating']; 
                                $featured= $rows['featured'];
                                $stock= $rows['stock'];
                                $active=$rows['active'];
                                $sl = $sl + 1;

                            ?>
                             <tr>
                                <td > <?php echo $sl ?></td>
                                <td > <img src ="image/products/<?php echo  $image  ?>" height="100px" > </td>                                
                                <td ><?php  echo $title  ?></td>
                                <td ><?php  echo $price  ?>TAKA</td>
                                <!--<td ><?php  echo $rating ?></td> -->
                                <td ><?php  echo $featured  ?></td>
                                <td ><?php  echo $stock  ?></td>
                                <td ><?php  echo $active  ?></td>
                                <td >
                                      <a href="edit_products.php?edit=<?php echo $id; ?>" class="clr-vpp1"> Update Products </a>
                                        
                                        <a href="?delete=<?php echo $id; ?>" class="clr-vpp2" onclick="return confirm('Are you sure?')"> Delete Products </a>
                                </td>
                            </tr>
                            
                         <?php

                     }
                    }
                     else{

                     }
                 }

               ?>
                

             </table>
             
        </div>

    </div>
         <!-- Main content section end -->
<?php include('partials/footer.php') ?>