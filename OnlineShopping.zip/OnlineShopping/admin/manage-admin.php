

<?php include('partials/menu.php') ?>
    <!-- Main content section starts -->
    <div class="main-content">
        <div class="wrapper">
             <!--<h1 align="center"> SR MART ONLINE SHOPPING </h1><br /> -->
            
             <h1> Manage Admin</h1>
             <br>

             <?php
			 if(isset($_GET["res"]) && $_GET["res"] == "Ok"){
				 echo "New Admin Added";
			 }
             if(isset($_GET["res"]) && $_GET["res"] == "No"){
                echo "Invalid";
             }
			 ?>

            <?php
			 if(isset($_GET["update"]) && $_GET["update"] == "Ok"){
				 echo "Successfully Update";
			 }
             if(isset($_GET["update"]) && $_GET["update"] == "No"){
                echo "Invalid";
             }
			 ?>

             
           <?php
            if(isset($_GET["delete"])){
				$del = $_GET["delete"];
				$delete_sql = "DELETE FROM tbl_admin WHERE id=".$del;
				$del_res = mysqli_query($conn, $delete_sql);
				if($del_res == True){
					echo '<script>alert("Data Delete Success")</script>';
				}else{
					echo '<script>alert("Data Delete Failed")</script>';
				}
				
			 }
             ?>

             <!-- Botton to add admin-->
            <!-- <a href="#" class=" btn btn-success" > Add Admin </a> <br><br> -->
             <br><br>
             <a href="add-admin.php" class="clr-vpp"> Add Admin </a> <br> <br>

             <table class="tbl-full">
                 
                <tr> 
                    <th> S.N.</th>
                    <th> Full Name</th>
                    <th> Username</th>
                    <th> Actions </th>
                </tr>
            
               <?php 
                 $sql= "SELECT * FROM tbl_admin";
                 $res = mysqli_query($conn , $sql);

                 if($res == True)
                 {
                     $count =mysqli_num_rows($res);

                     if($count>0)
                     {
                          $sl=0;
                            while($rows= mysqli_fetch_assoc($res))
                            {
                                $id= $rows['id'];
                                $full_name =$rows['full_name'];
                                $username=$rows['username'];
                                $sl = $sl + 1;

                            ?>
                             <tr>
                                <td > <?php echo $sl ?></td>
                                <td ><?php echo  $full_name  ?></td>
                                <td ><?php  echo $username  ?></td>
                                <td >
                                        <a href="edit_admin.php?edit=<?php echo $id; ?>" class="clr-vpp1"> Update Admin </a>
                                        
                                        <a href="?delete=<?php echo $id; ?>" class="clr-vpp2" onclick="return confirm('Are you sure?')"> Delete Admin </a>
                                </td>
                            </tr>
                            
                         <?php

                     }
                    }
                     else{

                     }
                 }

               ?>
                

             </table>
             
        </div>

    </div>
         <!-- Main content section end -->
<?php include('partials/footer.php') ?>
