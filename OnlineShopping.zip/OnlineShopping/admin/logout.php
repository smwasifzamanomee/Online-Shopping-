<?php
    //logout
    include('config/constants.php');
    //destory the sesstion
    session_destroy();

    //back to login page
    header("Location: login.php?");
?>