
<?php include('partials/menu.php') ?>
    <!-- Main content section starts -->
    <div class="main-content">
        <div class="wrapper">
             <!--<h1 align="center"> SR MART ONLINE SHOPPING </h1><br /> -->
            
             <h1> Add Admin</h1>
             <br>



             <form action="" method="POST">

                <table class="tbl-30">
                    <tr>
                        <td> FULL NAME </td>
                        <td> <input type="text" name="full_name" placeholder=" Enter Your Name"> </td>
                    </tr>
                    <tr>
                        <td> USER NAME </td>
                        <td> <input type="text" name="username" placeholder=" Enter Your Username"> </td>
                    </tr>
                    <tr>
                        <td> PASSWORD  </td>
                        <td> <input type="password" name="password" placeholder=" Enter Your Password"> </td>
                    </tr>
                    <tr>
                        
                        <td colspan="2"> <input type="submit" name="submit" value="Add Admin" class="clr-vpp1"> </td>
                    </tr>

                </table>


            </form>
             
        </div>

    </div>

    <?php 
       if(isset($_POST['submit']))
       {
            $full_name=$_POST['full_name'];
            $username=$_POST['username'];
            $password=$_POST['password'];

            //SQL
          /*  $sql= "INSERT INTO tbl_admin SET 
                   full_name='$full_name',
                   username='$username',
                   password='$password'
            "; */
            $sql= "INSERT INTO tbl_admin (full_name,username,password) VALUES ('$full_name','$username','$password')";

            //connection Database
        
           
            $res= mysqli_query($conn, $sql) or die(mysqli_error());

            if($res==true)
            {
               // echo "data show";
               //$_SESSION['add']="Admin Added Successfully";


              header("Location: manage-admin.php?res=Ok");
            }
            else{
                   // echo "data show failed";
                   header("Location: manage-admin.php?res=No");
            }
       }
    ?>
         <!-- Main content section end -->
<?php include('partials/footer.php') ?>
