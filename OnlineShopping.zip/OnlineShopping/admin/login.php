<?php include('config/constants.php')?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Online Shopping System</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="login">
        <h1 class="text-center">Login</h1>

       

        <!-- Login form start -->
        <br>
        <form action="" method="Post" class="text-center">
        Username:
        <input type="text" name="username" placeholder="Enter Username"><br><br>
        Password: 
        <input type="text" name="password" placeholder="Enter Password"> <br><br>

        <input type="submit" name="submit" value="login" class="clr-vpp">
        </form>
        <br><br>
        <!-- End-->
        <p class="text-center">Created by - Wasif Zaman Omee </p>
    </div>
</body>
</html>

<?php
    //check submit button 
    if(isset($_POST['submit']))
    {
        //login posc 
        $username = $_POST['username'];
        $password = $_POST['password'];

        //sql qry

        $sql="SELECT * FROM tbl_admin WHERE username='$username' AND password='$password'";

        //Excute qry
        $res= mysqli_query($conn, $sql);

        //user exit or not

        $count = mysqli_num_rows($res);

        if($count==1)
        {
            //login success
            header("Location: index.php?res=Login-Successful");
        }
        else
        {
            //login fail
            header("Location: login.php?res=Login-Unsuccessful");
        }

    }
?>