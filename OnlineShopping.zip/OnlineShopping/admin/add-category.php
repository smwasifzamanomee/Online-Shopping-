<?php include('partials/menu.php') ?>


<div class="main-content">
        <div class="wrapper">
            
             <h1> Add Category </h1> <br>

             <form action="" method="POST" enctype="multipart/form-data">

        <table class="tbl-30">
            <tr>
                <td> TITLE </td>
                <td> <input type="text" name="title" placeholder=" category title"> </td>
            </tr>
            <tr>
                <td> SELECT IMAGE </td>
                <td> <input type="file" name="image"> </td>
            </tr>
            <tr>
                <td> FEATURED </td>
                <td> 
                    <input type="radio" value="Yes" name="featured" placeholder=" Yes"> Yes
                    <input type="radio" value="No" name="featured" placeholder=" No"> No
                </td>
            </tr>
            <tr>
                <td> ACTIVE  </td>
                <td> 
                    <input type="radio" value="Yes" name="active" placeholder=" Yes"> Yes
                    <input type="radio" value="No" name="active" placeholder=" No"> No
                </td>
            </tr>
            <tr>
                
                <td colspan="2"> <input type="submit" name="submit" value="Add Category" class="clr-vpp1"> </td>
            </tr>

        </table>
        </form>

</div>
</div>

    <?php 
       
       if(isset($_POST['submit']))
       {
          $title = $_POST['title'];

           if(isset($_POST['featured']))
           {
               $featured = $_POST['featured'];
           }
           else{
               $featured="No";
           }

           if(isset($_POST['active']))
           {
               $active= $_POST['active'];
           }
           else{
               $active = "No";
           } 
           /*$title=$_POST['title'];
            $featured=$_POST['featured'];
            $active=$_POST['active'];*/

           // executed image 
           if(isset($_FILES['image']['name']))
           {
                $image_name = $_FILES['image']['name'];
                // image jpg formate
                $ext = end(explode('.', $image_name));
                //rename image
                $image_name= "product_category_" .rand(000 , 999).'.' .$ext;
                $source_path = $_FILES['image']['tmp_name'];
                $destination_path = "image/category/".$image_name;
                $upload =  move_uploaded_file($source_path, $destination_path);
           }
           else{
                    $image_name="";
           }

           //SQL

           $sql= "INSERT INTO tbl_category (title,image_name, featured, active) VALUES ('$title','$image_name','$featured','$active')";

           // executed database

           $res= mysqli_query($conn , $sql);

           // check executed or not 
           if($res==true)
            {
               // echo "data show";
               //$_SESSION['add']="Admin Added Successfully";


              header("Location: manage-category.php?res=Ok");
            }
            else{
                   // echo "data show failed";
                   header("Location: manage-category.php?res=No");
            }
       }
    ?>



             
<?php include('partials/footer.php') ?>