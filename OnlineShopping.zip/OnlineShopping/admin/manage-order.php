<?php include('partials/menu.php') ?>

 <!-- Main content section starts -->
 <div class="main-content">
        <div class="wrapper">
             <!--<h1 align="center"> SR MART ONLINE SHOPPING </h1><br /> -->
            
             <h1> Manage order </h1>
             <br>
             <table class="tbl-full">
                <tr> 
                    <th> Order No.</th>
                    <th> Order Date</th>
                    <th> Total price</th>
                    <th> Customer Name </th>
                    <th> Customer Contact </th>
                    <th> Customer Email </th>
                    <th> Customer Adress </th>
                    <th> Status </th>
                    <th> View </th>
                </tr>
            



				<?php
				$sql = "SELECT * FROM tbl_order";
				$res = mysqli_query($conn, $sql);
				if(mysqli_num_rows($res) > 0){
					while($row = mysqli_fetch_assoc($res)){
						$status = $row['status'];
						if($status == "Pending"){
							$status = "<span style='color: white'>$status</span>"; //change pending color here
						}else{
							$status = "<span style='color: green'>$status</span>";
						}
						echo "<tr><td>".$row['id']."</td>";
						echo "<td>".$row['order_date']."</td>";
						echo "<td>".$row['total']."</td>";
						echo "<td>".$row['customer_name']."</td>";
						echo "<td>".$row['customer_contacts']."</td>";
						echo "<td>".$row['customer_email']."</td>";
						echo "<td>".$row['customer_address']."</td>";
						echo "<td>".$status."</td>";
						echo "<td><a href='order_details.php?id=".$row['id']."' target='_blank'><button class='btn'>View</button></a></td></tr>"; //change button design here
					}
				}else{
					echo '<tr><td colspan="9"><center><h2>No Order Found</h2></center></td></tr>';
				}
				?>

                

             </table>
             
        </div>

    </div>
         <!-- Main content section end -->
<?php include('partials/footer.php') ?>