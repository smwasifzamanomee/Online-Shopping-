<?php
include('admin/config/constants.php');
// $ip = $_SERVER['REMOTE_ADDR'];
$sql = "SELECT * FROM cart";
$res = mysqli_query($conn, $sql);
$count = @mysqli_num_rows($res);
if($count <= 0){
	$count = 0;
}

$date = date("Y-m-d");

?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>SR Mart | Online Shopping</title>
        <link rel="stylesheet" href="style.css">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="cart.js"></script>
		<link rel="stylesheet" href="style1.css">
    </head>
    <body>
        <div class="header">
        <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="index.php"><img src="Images/logo.jpg" width="125px"> </a>
            </div>
            <nav>
                <ul id="MenuItems">
                    <li> <a href="index.php">Home</a></li>
                    <li> <a href="category.php">Categories</a></li>
                    <li> <a href="products.php">Products</a></li>
                    <li> <a href="contact.php">Contact</a></li>
					<li> <a href="cart.php">Cart <sup>[<?php echo $count; ?>]</sup></a></li>
                   
                </ul>
            </nav>
            
        </div>
        </div>
        </div>
<br/>
        <div class="container">
            <h2>Shopping Cart</h2> <br><br>

<table style="width: 100% ; text-align:left">
	<thead>
		<th>Image</th>
		<th>Product Name</th>
		<th>Price</th>
		<th>Quantity</th>
		<th>Total</th>
		<th>Remove</th>
	</thead>
	<tbody>
	<?php

		$total = 0;
		if($count > 0){
			while($row=mysqli_fetch_assoc($res)){
				$subtotal = $row['subtotal'];
				$total = $total + $subtotal;
				$product = $row['product'];
				$psql = "SELECT * FROM tbl_products WHERE id=".$product;
				$pres = mysqli_query($conn, $psql);
				$prow = mysqli_fetch_assoc($pres);


	?>
		<tr>
			
			<td><br><img src="admin/image/products/<?php echo $prow['image_name']; ?>" height="100px"></td>
			<td><?php echo $prow['title']; ?></td>
			<td><?php echo $row['price']; ?></td>
			<td><?php echo $row['qty']; ?></td>
			<td><?php echo $subtotal; ?></td>
			<td><a href="?delete=<?php echo $row['id']; ?>"><button style="color:darkred; font-weight: bold; padding: 2px">X</button></a></td>
			<?php
			if(isset($_GET['delete'])){
				$id = $_GET['delete'];
				$dsql = "DELETE FROM cart WHERE id=".$id;
				$dres = mysqli_query($conn, $dsql);
				if(!$dres){
					echo "<script>alert('something went wrong');</script>";
				}else{
					header("Location: cart.php");
				}
			}
			?>
		</tr>

		<?php
			}
		}else{
			echo "<h3>Empty Cart</h3>";
			
		}
		?>
		<br>
		<tr>
			
			<td colspan="4" style="text-align:right; font-weight: bold;"><br>Total Price: </td>
			<td><br><?php echo $total; ?></td>
			<!--<td><button class="btn">Place Order</button></td>-->
		</tr>
	</tbody>
</table>
<br><br>
<div class="container">
	<h2>Customer Information</h2>
	<form method="POST">
		<table width="auto">
			<tr><td>Customer Name </td><td><input type="text" name="name" style="width:400px;padding:2px"></td></tr>
			<tr><td>Customer Mobile </td><td><input type="text" name="contact" style="width:400px;padding:2px"></td></tr>
			<tr><td>Customer Email </td><td><input type="text" name="email" style="width:400px;padding:2px"></td></tr>
			<tr><td>Customer Address </td><td><input type="text" name="address" style="width:400px;padding:2px"></td></tr>
			</tr>
		</table>
		<input type="submit" class="btn" name="order" value="Confirm Order">
	</form>
</div>

<?php
if(isset($_POST["order"])){
	$name = $_POST["name"];
	$contact = $_POST["contact"];
	$email = $_POST["email"];
	$address = $_POST["address"];
	
	$order_sql = "INSERT INTO tbl_order(total, order_date, status, customer_name, customer_contacts, customer_email, customer_address) VALUES(".$total.", '".$date."', 'Pending', '".$name."', '".$contact."', '".$email."', '".$address."')";
	// echo $order_sql;
	$order_res = mysqli_query($conn, $order_sql);
	if($order_res){
		$last_id = mysqli_insert_id($conn);
		// echo $last_id;
		$sql = "SELECT * FROM cart";
		$res = mysqli_query($conn, $sql);
		$count = @mysqli_num_rows($res);
		if($count <= 0){
			$count = 0;
		}
		$ok = "false";
		if($count > 0){
			while($row=mysqli_fetch_assoc($res)){
				$product = $row['product'];
				$qty = $row['qty'];
				$price = $row['price'];
				$subtotal = $row['subtotal'];
				$order_detail_sql = "INSERT INTO order_details(order_id, product_id, price, qty, subtotal) VALUES(".$last_id.",".$product.",'".$price."',".$qty.",'".$subtotal."')";
				// echo $order_detail_sql;
				$order_detail_res = mysqli_query($conn, $order_detail_sql);
				$ok = "true";
				
			}
		}
		if($ok == "true"){
			$delete_cart = "DELETE FROM cart";
			$delete_cart_res = mysqli_query($conn, $delete_cart);
			echo "<script>alert('Order Has Been Placed Successfully');document.location='index.php'</script>";
			// header("Location: index.php");
		}else{
			echo "<script>alert('something went wrong in order placement');</script>";
		}
	}else{
		echo "<script>alert('something went wrong');</script>";
	}
	
}
?>
