
<?php include('admin/config/constants.php'); ?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>SR Mart | Online Shopping</title>
        <link rel="stylesheet" href="style.css">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="header">
        <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="index.php"><img src="Images/logo.jpg" width="125px"> </a>
            </div>
            <nav>
                <ul id="MenuItems">
                    <li> <a href="index.php">Home</a></li>
                    <li> <a href="category.php">Categories</a></li>
                    <li> <a href="products.php">Products</a></li>
                    <li> <a href="contact.php">Contact</a></li>
                </ul>
            </nav>
            
        </div>
        </div>
        </div>

        <!-- Order From -->
        
        <div class="container">
            <h2 class="text-center text-white">Fill this form to confirm your order.</h2>

        <form action=""  >
        <fieldset>
            <legend> Selected Products </legend>
            <div class="product-manu-img">
                <img src="1.jpg" alt="shoe" class="">
            </div>
            <div class="products-manu-des">
                <h3>title</h3>
                <p class="">price </p>
                <div class="order-label">Quantity</div> 
                <input type="number" name="qty" value="1" class="input-responsive">
            </div>
        </fieldset>
        <fieldset>
            <legend>Delivery Details</legend>
            <div class="order-label">Full Name</div>
            <input type="text" name="full-name" placeholder="E.g. Wasif Zaman Omee" class="input-responsive" required>

            <div class="order-label">Phone Number</div>
            <input type="tel" name="contact" placeholder="E.g. 019########" class="input-responsive" required>

            <div class="order-label">Email</div>
            <input type="email" name="email" placeholder="E.g. Wasifbdjsr@gmail.com" class="input-responsive" required>

            <div class="order-label">Address</div>
            <textarea name="address" row="10" placeholder="E.g. house no,street,city " class="input-responsive" required></textarea>
            <br>
            <input type="submit" name="submit" value="Confirm Order" class="btn">
            <input type="submit" name="submit" value="Cancel Order" class="btn">
        </fieldset>
        </form>
</div>
</div
       
        
        <!--- footer --->
        
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-col-1">
                        <h3>Download Our App</h3>
                        <p>Download App for Andriod and iso mobile phone</p>
                        <div class="app-logo">
                            <img src="Images/playstore.png">
                            <img src="Images/appstore.png" height="56.5px">
                        </div>
                    </div>
                    <div class="footer-col-2">
                        <img src="Images/logo.jpg">
                        <p>our Purpose is to sustainably make the pleasure and benefits of sports accessible to the way</p>
                    </div>
                    <div class="footer-col-4">
                        <h3>Follow Us</h3>
                        <ul>
                            <li>Facebook</li>
                            <li>Twitter</li>
                            <li>Instagram</li>
                            <li>Youtube</li>
                        </ul>
                    </div>
                    
                </div>
                <hr>
                <p align="center">2021 All rights reserved, Online Shopping. Developed by Wasif Zaman Omee</p>
            </div>
        </div>
    </body>   
</html>