
<?php
include('admin/config/constants.php');
// $ip = $_SERVER['REMOTE_ADDR'];
$sql = "SELECT * FROM cart";
$res = mysqli_query($conn, $sql);
$count = @mysqli_num_rows($res);
if($count <= 0){
	$count = 0;
}


?>


<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>SR Mart | Online Shopping</title>
        <link rel="stylesheet" href="style.css">
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="header">
        <div class="container">
        <div class="navbar">
            <div class="logo">
                <a href="index.php"><img src="Images/logo.jpg" width="125px"> </a>
            </div>
            <nav>
                <ul id="MenuItems">
                    <li> <a href="index.php">Home</a></li>
                    <li> <a href="category.php">Categories</a></li>
                    <li> <a href="products.php">Products</a></li>
                    <li> <a href="contact.php">Contact</a></li>
                    <li> <a href="cart.php">Cart <sup>[<?php echo $count; ?>]</sup></a></li>
                   
                </ul>
            </nav>
            
        </div>
</div>
</div>
</div>
        
       <!-- featured products -->

       <div clas="small-container">
            <h2 class="title">Products</h2><br><br>
            <div class="row">
         <?php
        $sql= "SELECT * FROM tbl_products";
        $res = mysqli_query($conn , $sql);

        if($res == True)
        {
            $count =mysqli_num_rows($res);

            if($count>0)
            {
                while($rows= mysqli_fetch_assoc($res))
                {
                    $id= $rows['id'];
                    $image= $rows['image_name'];
                    $title =$rows['title'];
                    $stock =$rows['stock'];

                    if($stock=="No")
                    {
                        $stock = "<sup style='color:red'> Stock Out</sup>";
                    }
                    else
                    {
                        $stock="";
                    }
                    //$rating =$rows['rating'];
                    $price =$rows['price'];
                    $active=$rows['active'];
                    if($active=="Yes"){


                        ?>
                    <div class="col-5">
                    <img src="admin/image/products/<?php echo $image ?>">
                    <h4><?php echo $title.$stock ?></h4>
                    <div class="rating">
                        <i class="fa fa-star"> </i>
                        <i class="fa fa-star"> </i>
                        <i class="fa fa-star"> </i>
                        <i class="fa fa-star"> </i>
                        <i class="fa fa-star-half-o"> </i>

                    </div>
                    <p><?php echo $price ?>TAKA</p>
					<form method="POST">
						<input type="number" name="qty" value="1" min="1">
						<input type="hidden" name="id" value="<?php echo $id; ?>">
						<input type="hidden" name="price" value="<?php echo $price; ?>">
						<input type="submit" class="btn" name="cart" value="Add To Cart">
					</form>
					
					
					
					
					
					
                </div>
                
     <?php
                }
            }
         }
            else{
                echo "No Products Found";
                 
                }   

        }  
    ?>


                </div>
            </div>
        </div>
<?php
if(isset($_POST['cart'])){
	$pid = $_POST['id'];
	$price = $_POST['price'];
	$qty = $_POST['qty'];
	$subtotal = $qty*$price;
	// $identifier = $ip;
	
	$ins_sql = 'INSERT INTO cart(product,qty,price,subtotal,identity) VALUES("'.$pid.'",'.$qty.',"'.$price.'","'.$subtotal.'","")';
	echo $ins_sql;
	$ins_query = mysqli_query($conn, $ins_sql);
	if($ins_query){
		echo '<script>alert("Product added into cart");document.location="products.php"</script>';
	}else{
		echo '<script>alert("Something went wrong");</script>';
	}

}

?>    
        
        <!--- footer --->
        
        <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-col-1">
                        <h3>Download Our App</h3>
                        <p>Download App for Andriod and iso mobile phone</p>
                        <div class="app-logo">
                            <img src="Images/playstore.png">
                            <img src="Images/appstore.png" height="56.5px">
                        </div>
                    </div>
                    <div class="footer-col-2">
                        <img src="Images/logo.jpg">
                        <p>our Purpose is to sustainably make the pleasure and benefits of sports accessible to the way</p>
                    </div>
                    <div class="footer-col-4">
                        <h3>Follow Us</h3>
                        <ul>
                            <li>Facebook</li>
                            <li>Twitter</li>
                            <li>Instagram</li>
                            <li>Youtube</li>
                        </ul>
                    </div>
                    
                </div>
                <hr>
                <p align="center">2021 All rights reserved, Online Shopping. Developed by Wasif Zaman Omee</p>
            </div>
        </div>
    </body>   
</html>